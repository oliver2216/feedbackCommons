package com.cg.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class Feedback {

	@Id
	@Column(name="Feedback_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Feedback_Id;

	@Column(name="Customer_Id")
	private int customerId;
	
	@Column(name="Merchant_Id")
	private int merchantId;

	
	@Column(name="Feedback_Comment")
	private String feedbackComment;
	
	@Column(name="Response")
	private String response;
	
	@Column(name="Status")
	private String status;


	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	

	public int getFeedback_Id() {
		return Feedback_Id;
	}

	public void setFeedback_Id(int feedback_Id) {
		Feedback_Id = feedback_Id;
	}

	public String getFeedbackComment() {
		return feedbackComment;
	}

	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
		
	
}
