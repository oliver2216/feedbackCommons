package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.capstore.beans.Feedback;
import com.cg.capstore.beans.Reply;
import com.cg.capstore.dao.FeedbackRepo;

@Service
public class FeedbackCommonServiceImpl implements IFeedbackCommonService {

	@Autowired
	FeedbackRepo frepo;
	
	@Override
	public void generateRequest(Feedback feedback) {
		
		frepo.save(feedback);
		
	}

	@Override
	public List<Feedback> viewAllFeedbackRequests() {
		
		return frepo.findByStatus("Requested");
		
	}
	
	@Override
	public void forwardToMerchant(int feedback_id) {
		
		Feedback temp=frepo.findById(feedback_id).get();
		temp.setStatus("Forwarded");
		frepo.save(temp);
		
		
	}

	@Override
	public List<Feedback> viewMyFeedbacks(int merchantId) {
		
		return frepo.findByStatus("Forwarded");
		
	}

	@Override
	public void sendResponseToAdmin(int feedback_id,Reply response) {
		
		Feedback temp=frepo.findById(feedback_id).get();
		temp.setResponse(response.getResponse());
		temp.setStatus("Replied");
		frepo.save(temp);
		
	}

	@Override
	public List<Feedback> viewAllResponses() {
		
		return frepo.findAllByStatus("Replied");
		
	}

	@Override
	public void	sendResponseToCustomer(int responseId) {
		
		Feedback temp=frepo.findById(responseId).get();
		temp.setStatus("Responded");
		frepo.save(temp);	
	}

	@Override
	public List<Feedback> showMyResponse(int cust_id) {

		return frepo.findAllByStatusAndCustomerId("Responded" ,cust_id);
		
	}
		
}

