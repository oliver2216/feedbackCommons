package com.cg.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.capstore.beans.Feedback;
import com.cg.capstore.beans.Reply;
import com.cg.capstore.beans.Response;


@Service
public interface IFeedbackCommonService {

	void generateRequest(Feedback feedback);

	List<Feedback> viewAllFeedbackRequests();
	
	void forwardToMerchant(int feedbackId);
	
	List<Feedback> viewMyFeedbacks(int merchantId);

	void sendResponseToAdmin(int feedback_id, Reply response);

	List<Feedback> viewAllResponses();

	void sendResponseToCustomer(int responseId);

	List<Feedback> showMyResponse(int cust_id);

	
}
